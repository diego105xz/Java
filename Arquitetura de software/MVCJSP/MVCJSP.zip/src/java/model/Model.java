package model;
import java.io.Serializable;
import java.sql.Connection;

/**
 *
 * @author souza
 * Essa classe controla o acesso ao banco de dados
 * Teremos os seguintes métodos:
 * inserir, pesquisar*, editar, atualizar, excluir
 * pesquisar (listar e listar todos)
 */
public class Model implements Serializable{
    private Connection connection = null;
    private String statusMessage;
    
    public void insert(Object aluno){
        this.statusMessage = "Inserido com sucesso!";
    }
}
